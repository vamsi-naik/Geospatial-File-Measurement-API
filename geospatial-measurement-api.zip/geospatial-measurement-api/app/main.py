from fastapi import FastAPI
from app.api.routes import router

app = FastAPI(
    title="Geospatial File Measurement API",
    description="API for processing KML and Shapefile files and calculating geospatial measurements.",
    version="1.0.0",
)

app.include_router(router, prefix="/api")

@app.get("/")
def root():
    return {"message": "Geospatial File Measurement API", "docs": "/docs", "version": "1.0.0"}

@app.get("/health")
def health_check():
    return {"status": "healthy"}

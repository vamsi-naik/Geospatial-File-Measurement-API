import json
import shutil
import uuid
import zipfile
from pathlib import Path
from fastapi import UploadFile
from app.services.geospatial_service import calculate_measurements, get_crs_string, read_geospatial_file

BASE_DIR = Path(__file__).resolve().parents[2]
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_EXTENSIONS = {".kml", ".zip"}

def _metadata_path(file_id: str) -> Path:
    return UPLOAD_DIR / f"{file_id}.json"

def _storage_path(file_id: str) -> Path:
    return UPLOAD_DIR / file_id

async def process_uploaded_file(file: UploadFile) -> dict:
    filename = file.filename or ""
    extension = Path(filename).suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise ValueError("Unsupported file format. Upload a .kml file or a .zip containing a Shapefile.")

    file_id = uuid.uuid4().hex[:12]
    storage_directory = _storage_path(file_id)
    storage_directory.mkdir(parents=True, exist_ok=True)
    uploaded_path = storage_directory / filename

    with uploaded_path.open("wb") as output:
        shutil.copyfileobj(file.file, output)

    try:
        if extension == ".zip":
            extracted_directory = storage_directory / "extracted"
            extracted_directory.mkdir(exist_ok=True)
            with zipfile.ZipFile(uploaded_path, "r") as zip_file:
                for member in zip_file.namelist():
                    member_path = (extracted_directory / member).resolve()
                    if not str(member_path).startswith(str(extracted_directory.resolve())):
                        raise ValueError("Invalid ZIP archive.")
                zip_file.extractall(extracted_directory)
            shapefiles = list(extracted_directory.rglob("*.shp"))
            if not shapefiles:
                raise ValueError("ZIP file does not contain a Shapefile.")
            geospatial_path = shapefiles[0]
        else:
            geospatial_path = uploaded_path

        gdf = read_geospatial_file(str(geospatial_path))
        crs = get_crs_string(gdf)
        measurements = calculate_measurements(gdf)

        metadata = {
            "id": file_id,
            "filename": filename,
            "feature_count": len(gdf),
            "crs": crs,
            "status": "COMPLETED",
            "measurements": measurements,
        }
        with _metadata_path(file_id).open("w", encoding="utf-8") as metadata_file:
            json.dump(metadata, metadata_file, indent=2)

        return {
            "id": file_id,
            "filename": filename,
            "feature_count": len(gdf),
            "crs": crs,
            "status": "COMPLETED",
        }
    except Exception:
        if storage_directory.exists():
            shutil.rmtree(storage_directory)
        metadata_file = _metadata_path(file_id)
        if metadata_file.exists():
            metadata_file.unlink()
        raise

def _load_metadata(file_id: str) -> dict | None:
    metadata_file = _metadata_path(file_id)
    if not metadata_file.exists():
        return None
    with metadata_file.open("r", encoding="utf-8") as file:
        return json.load(file)

def get_file_information(file_id: str) -> dict | None:
    metadata = _load_metadata(file_id)
    if metadata is None:
        return None
    return {k: metadata[k] for k in ("id", "filename", "feature_count", "crs", "status")}

def get_measurements(file_id: str) -> dict | None:
    metadata = _load_metadata(file_id)
    if metadata is None:
        return None
    return {"file_id": file_id, "measurements": metadata["measurements"]}

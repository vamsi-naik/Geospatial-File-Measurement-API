import geopandas as gpd

def read_geospatial_file(file_path: str) -> gpd.GeoDataFrame:
    path = file_path.lower()
    if path.endswith(".kml"):
        gdf = gpd.read_file(file_path, driver="KML")
    elif path.endswith(".shp"):
        gdf = gpd.read_file(file_path)
    else:
        raise ValueError("Unsupported geospatial file format.")
    if gdf.empty:
        raise ValueError("The uploaded file contains no features.")
    return gdf

def get_crs_string(gdf: gpd.GeoDataFrame) -> str | None:
    if gdf.crs is None:
        return None
    try:
        epsg = gdf.crs.to_epsg()
        if epsg:
            return f"EPSG:{epsg}"
    except Exception:
        pass
    return str(gdf.crs)

def calculate_measurements(gdf: gpd.GeoDataFrame) -> list[dict]:
    measurement_gdf = gdf.copy()
    if measurement_gdf.crs is None:
        raise ValueError("The uploaded file does not contain a CRS.")
    if measurement_gdf.crs.is_geographic:
        projected_crs = measurement_gdf.estimate_utm_crs()
        if projected_crs is None:
            raise ValueError("Unable to determine a suitable projected CRS.")
        measurement_gdf = measurement_gdf.to_crs(projected_crs)

    results = []
    for index, geometry in measurement_gdf.geometry.items():
        original_geometry = gdf.geometry.loc[index]
        geometry_type = original_geometry.geom_type if original_geometry is not None else "Unknown"
        result = {
            "feature_id": int(index),
            "geometry_type": geometry_type,
            "measurement": None,
            "unit": None,
            "message": None,
        }

        if geometry is None or geometry.is_empty:
            result["message"] = "Geometry is empty or unavailable."
        elif geometry_type == "Polygon":
            result["measurement"] = float(geometry.area)
            result["unit"] = "square_meters"
        elif geometry_type == "LineString":
            result["measurement"] = float(geometry.length)
            result["unit"] = "meters"
        elif geometry_type == "Point":
            result["message"] = "No measurement required for Point geometry."
        else:
            result["message"] = f"Measurement is not supported for {geometry_type} geometry."

        results.append(result)
    return results

from fastapi import APIRouter, File, HTTPException, UploadFile, status
from app.schemas import FileInformationResponse, FileUploadResponse, MeasurementsResponse
from app.services.file_service import get_file_information, get_measurements, process_uploaded_file

router = APIRouter()

@router.post("/files/", response_model=FileUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_file(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Filename is required.")
    try:
        return await process_uploaded_file(file)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"File processing failed: {str(exc)}") from exc

@router.get("/files/{file_id}/", response_model=FileInformationResponse)
def file_information(file_id: str):
    result = get_file_information(file_id)
    if result is None:
        raise HTTPException(status_code=404, detail="File not found.")
    return result

@router.get("/files/{file_id}/measurements/", response_model=MeasurementsResponse)
def file_measurements(file_id: str):
    result = get_measurements(file_id)
    if result is None:
        raise HTTPException(status_code=404, detail="File not found.")
    return result

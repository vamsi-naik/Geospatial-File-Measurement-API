from typing import Optional
from pydantic import BaseModel

class FileUploadResponse(BaseModel):
    id: str
    filename: str
    feature_count: int
    crs: Optional[str] = None
    status: str

class FileInformationResponse(BaseModel):
    id: str
    filename: str
    feature_count: int
    crs: Optional[str] = None
    status: str

class MeasurementResponse(BaseModel):
    feature_id: int
    geometry_type: str
    measurement: Optional[float] = None
    unit: Optional[str] = None
    message: Optional[str] = None

class MeasurementsResponse(BaseModel):
    file_id: str
    measurements: list[MeasurementResponse]

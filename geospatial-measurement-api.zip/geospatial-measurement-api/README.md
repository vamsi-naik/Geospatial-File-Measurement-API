# Geospatial File Measurement API

A FastAPI backend service for uploading KML files and ZIP archives containing Shapefiles, extracting features, handling CRS, and calculating measurements.

## Features

- KML support
- ZIP Shapefile support
- Polygon area calculation
- LineString length calculation
- Point handling
- CRS transformation for geographic coordinates
- REST API
- Swagger documentation
- Automated tests
- Docker and Render deployment configuration

## Setup

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs

## API

### Upload
`POST /api/files/`

Accepts `.kml` or `.zip` containing a Shapefile.

### File information
`GET /api/files/{id}/`

### Measurements
`GET /api/files/{id}/measurements/`

### Health
`GET /health`

## CRS Handling

Geographic CRS such as EPSG:4326 uses latitude/longitude degrees. Area and distance are not calculated directly in degrees. When the input CRS is geographic, the service uses GeoPandas `estimate_utm_crs()` and reprojects the geometry before calculating measurements.

## Architecture

The API layer handles HTTP requests. The service layer handles file storage, extraction, geospatial processing, CRS transformation, and measurement calculation. Pydantic schemas define response structures.

## Design Decisions

FastAPI was selected for its simple Python API development and automatic Swagger documentation. GeoPandas, Shapely, and PyProj provide the geospatial processing functionality. JSON metadata storage keeps the assignment simple; PostgreSQL/PostGIS would be a stronger production choice.

## Testing

```bash
pytest
```

## Docker

```bash
docker build -t geospatial-measurement-api .
docker run -p 8000:8000 geospatial-measurement-api
```

## Learning

This project provides experience with FastAPI, REST APIs, file uploads, KML/Shapefile processing, CRS transformation, geospatial measurements, testing, Docker, and deployment.

## Future Scope

- PostgreSQL/PostGIS
- Authentication
- Background processing
- Additional geospatial formats
- MultiPolygon and MultiLineString measurements
- Cloud storage
- Pagination
- Improved global CRS selection

## Deployment

`render.yaml` is included for Render deployment. The Swagger UI will be available at `/docs` on the deployed service.

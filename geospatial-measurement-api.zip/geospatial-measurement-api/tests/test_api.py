from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["message"] == "Geospatial File Measurement API"

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_invalid_file_type():
    response = client.post("/api/files/", files={"file": ("test.txt", b"hello", "text/plain")})
    assert response.status_code == 400

def test_file_not_found():
    response = client.get("/api/files/not-found/")
    assert response.status_code == 404

def test_measurements_not_found():
    response = client.get("/api/files/not-found/measurements/")
    assert response.status_code == 404
